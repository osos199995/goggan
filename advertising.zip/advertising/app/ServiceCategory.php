<?php

namespace App;
use App\Service;
use App\ServiceSubCategory;

use Illuminate\Database\Eloquent\Model;

class ServiceCategory extends Model
{


    protected $fillable = [
        'name',
        'name_ar',
        'image'
    ];





    public function subcategory(){
        return $this->hasMany('App\ServiceSubCategory','service_category_id');

    }

        public function service(){
            return $this->hasMany('App\Service','service_category_id');




}




}
