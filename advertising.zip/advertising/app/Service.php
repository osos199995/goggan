<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    //

    protected $fillable=[

        'name',
        'name_ar',
        'description',
        'description_ar',
        'service_category_id',
        'service_subcategory_id',
        'image'





    ];
    public function category()
    {
        return $this->belongsTo('App\ServiceCategory', 'service_category_id');
    }

    public function subcategory()
{
    return $this->belongsTo('App\ServiceSubCategory','service_subcategory_id');
}
}
