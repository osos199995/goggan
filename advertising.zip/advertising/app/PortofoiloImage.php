<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PortofoiloImage extends Model
{
    //
    protected $fillable=[

        'portofoilo_id',
        'image'
        ];
}
