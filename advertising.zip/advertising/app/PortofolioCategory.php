<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PortofolioCategory extends Model
{
    protected $fillable=[
        'image',
        'name',
        'name_ar',
    ];



    public function portofolios(){
        return $this->hasMany('App\Portofolio','portofolio_category_id');
    }



}

