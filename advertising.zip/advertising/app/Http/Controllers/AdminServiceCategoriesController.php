<?php

namespace App\Http\Controllers;
use App\ServiceCategory;
use App\ServiceSubCategory;
use App\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminServiceCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories=ServiceCategory::all();
        return view('admin.service.category',compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'image'=>'required|image|mimes:jpg,png,jpeg'
        ]);
        $input=$request->all();
        if($file=$request->file('image')){
            $name=time().$file->getClientOriginalName();
            $file->move('service_categories',$name);
            $input['image']=$name;
        }

        ServiceCategory::create($input);
        Session::flash('success','Category Added Successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input=$request->all();
        if($file=$request->file('image')){
            $path=ServiceCategory::find($id)->image;
            if($path && file_exists(public_path().'/service_categories/'.$path)){
                unlink(public_path().'/service_categories/'.$path);
            }
            $name=time().$file->getClientOriginalName();
            $file->move('service_categories',$name);
            $input['image']=$name;
        }

        ServiceCategory::find($id)->update($input);
        Session::flash('success','Category Updated Successfully');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $category=ServiceCategory::find($id);
        if($category->image && file_exists(public_path().'/service_categories/'.$category->image)){
            unlink(public_path().'/service_categories/'.$category->image);
        }

        $services=Service::Where('service_category_id',$id)->get();

        foreach ($services as $service) {

            if($service->image && file_exists(public_path().'/service_categories/'.$service->image)){
                unlink(public_path().'/service_categories/'.$service->image);
            }

            $service->delete();
        }

        $subcategories=ServiceSubCategory::Where('service_category_id',$id)->get();

        foreach ($subcategories as $subcategory) {


            if($subcategory->image && file_exists(public_path().'/service_categories/'.$subcategory->image)){
                unlink(public_path().'/service_categories/'.$subcategory->image);
            }

            $subcategory->delete();

        }


        $category->delete();
        Session::flash('danger','Category Deleted Successfully');
        return redirect()->back();
    }
}
