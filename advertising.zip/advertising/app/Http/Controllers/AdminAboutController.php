<?php

namespace App\Http\Controllers;

use App\About;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminAboutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $about=About::first();
        return view('admin.about.index',compact('about'));
    }


    public function edit($id)
    {
        $about=About::find($id);
        return view('admin.about.edit',compact('about'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'mission'=>'required',
            'mission_ar'=>'required',
            'vision'=>'required',
            'vision_ar'=>'required',
            'value'=>'required',
            'value_ar'=>'required',
        ]);
        $input=$request->all();
        if($file=$request->file('image')){
          $path=About::find($id)->image;
              if($path && file_exists(public_path().'/about/'.$path)){
                  unlink(public_path().'/about/'.$path);
              }
              $name=time().$file->getClientOriginalName();
              $file->move('about',$name);
              $input['image']=$name;
        }

        About::find($id)->update($input);
        Session::flash('success','About Details updated Successfully');
        return redirect('admin-about');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
