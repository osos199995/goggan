<?php

namespace App\Http\Controllers;


use App\PortofoiloImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;


class AdminPortofoiloImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $images = PortofoiloImage::all();
        return view('admin.portofolio.image',compact('images'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

            $request->validate([
                'image'=>'required|image|mimes:jpg,png,jpeg'
            ]);
            $input=$request->all();
            if($file=$request->file('image')){
                $name=time().$file->getClientOriginalName();
                $file->move('portfolio_images',$name);
                $input['image']=$name;
            }

            PortofoiloImage::create($input);
            Session::flash('success','Category Added Successfully');
            return redirect()->back();


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        {
            $input=$request->all();
            if($file=$request->file('image')){
                $path=PortofoiloImage::find($id)->image;
                if($path && file_exists(public_path().'/portfolio_images/'.$path)){
                    unlink(public_path().'/portfolio_images/'.$path);
                }
                $name=time().$file->getClientOriginalName();
                $file->move('portfolio_images',$name);
                $input['image']=$name;
            }

            PortofoiloImage::find($id)->update($input);
            Session::flash('success','Category Updated Successfully');
            return redirect()->back();
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $image=PortofoiloImage::find($id);
        if($image->image && file_exists(public_path().'/portfolio_images/'.$image->image)){
            unlink(public_path().'/portfolio_images/'.$image->image);
        }
        $image->delete();
        Session::flash('danger','Image Deleted Successfully');
        return redirect()->back();
    }
}
