<?php

namespace App\Http\Controllers;
use App\PortofoiloImage;
use App\PortofolioCategory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

use App\Portofolio;
use Illuminate\Http\Request;

class AdminPortofolioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $portolios= Portofolio::all();
        return view('admin.portofolio.index',compact('portolios'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories=PortofolioCategory::all();
        return view('admin.portofolio.create',compact('categories'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $request->validate([
            'image.*'=>'required|image|mimes:jpg,png,jpeg',
            'description'=>'required',
            'description_ar'=>'required',
        ]);
        $input=$request->all();


        $portfolio=Portofolio::create($input);

        if($files=$request->file('images')){
            foreach ($files as $file){
                $name=time().$file->getClientOriginalName();
                $file->move('portfolio_images',$name);

                PortofoiloImage::create([
                    'image'=>$name,
                    'portofoilo_id'=>$portfolio->id
                ]);
            }

        }

        Session::flash('success','Category Added Successfully');
        return redirect('admin-portofolio');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $portfolio=Portofolio::find($id);

        return view('admin.portofolio.show',compact('portfolio'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $portfolio=Portofolio::find($id);
        $categories=PortofolioCategory::all();

        return view('admin.portofolio.edit',compact('categories','portfolio'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $request->validate([
            'image.*'=>'required|image|mimes:jpg,png,jpeg',
            'description'=>'required',
            'description_ar'=>'required',
        ]);
        $input=$request->all();


        $portfolio=Portofolio::find($id)->update($input);
        if($files=$request->file('images')){
            $old_images=PortofoiloImage::where('portofoilo_id',$id)->get();
            foreach ($old_images as $image){
                if(file_exists(public_path().'/portfolio_images/'.$image->image)){
                    unlink(public_path().'/portfolio_images/'.$image->image);
                }
            }
            DB::table('portofoilo_images')->where('portofoilo_id',$id)->delete();

            foreach ($files as $file){
                $name=time().$file->getClientOriginalName();
                $file->move('portfolio_images',$name);

                PortofoiloImage::create([
                    'image'=>$name,
                    'portofoilo_id'=>$id
                ]);
            }

        }

        Session::flash('success','Portfolio Updated Successfully');
        return redirect('admin-portofolio');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $portofolio = Portofolio::find($id);
        $old_images=PortofoiloImage::where('portofoilo_id',$id)->get();
        foreach ($old_images as $image){
            if(file_exists(public_path().'/portfolio_images/'.$image->image)){
                unlink(public_path().'/portfolio_images/'.$image->image);
            }
        }
        $portofolio->delete();
        Session::flash('danger','Category Deleted Successfully');
        return redirect()->back();
    }
}
