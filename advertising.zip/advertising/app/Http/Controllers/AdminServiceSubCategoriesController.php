<?php

namespace App\Http\Controllers;

use App\ServiceCategory;
use App\ServiceSubCategory;
use App\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminServiceSubCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subcategories=ServiceSubCategory::all();
        $categories=ServiceCategory::all();

        return view('admin.service.subcategories',compact('categories','subcategories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = ServiceSubCategory::all();
        return view('admin.service.subcategories.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//        $request->validate([
//            'image'=>'required|image|mimes:jpg,png,jpeg'
//        ]);
        $input=$request->all();

        if($file=$request->file('image')){
            $name=time().$file->getClientOriginalName();
            $file->move('service_categories',$name);
            $input['image']=$name;
        }

        ServiceSubCategory::create($input);
        Session::flash('success','SubCategory Added Successfully');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input=$request->all();
        if($file=$request->file('image')){
            $path=ServiceSubCategory::find($id)->image;
            if($path && file_exists(public_path().'/service_categories/'.$path)){
                unlink(public_path().'/service_categories/'.$path);
            }
            $name=time().$file->getClientOriginalName();
            $file->move('service_categories',$name);
            $input['image']=$name;
        }

        ServiceSubCategory::find($id)->update($input);
        Session::flash('success','subCategory Updated Successfully');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $category=ServiceSubCategory::find($id);
        if($category->image && file_exists(public_path().'/service_categories/'.$category->image)){
            unlink(public_path().'/service_categories/'.$category->image);
        }

        $services=Service::Where('service_subcategory_id',$id)->get();

        foreach ($services as $service) {

            if($service->image && file_exists(public_path().'/service_categories/'.$service->image)){
                unlink(public_path().'/service_categories/'.$service->image);
            }

            $service->delete();
        }



        $category->delete();
        Session::flash('danger','subCategory Deleted Successfully');
        return redirect()->back();
    }
}
