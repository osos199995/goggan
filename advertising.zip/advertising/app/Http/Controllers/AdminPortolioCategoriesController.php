<?php

namespace App\Http\Controllers;

use App\Portofolio;
use App\PortofolioCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminPortolioCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories=PortofolioCategory::all();
        return view('admin.portofolio.category',compact('categories'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'image'=>'required|image|mimes:jpg,png,jpeg'
        ]);
        $input=$request->all();
        if($file=$request->file('image')){
              $name=time().$file->getClientOriginalName();
              $file->move('portfolio_categories',$name);
              $input['image']=$name;
        }

        PortofolioCategory::create($input);
        Session::flash('success','Category Added Successfully');
        return redirect()->back();

    }


    public function update(Request $request, $id)
    {
        $input=$request->all();
        if($file=$request->file('image')){
          $path=PortofolioCategory::find($id)->image;
              if($path && file_exists(public_path().'/portfolio_categories/'.$path)){
                  unlink(public_path().'/portfolio_categories/'.$path);
              }
              $name=time().$file->getClientOriginalName();
              $file->move('portfolio_categories',$name);
              $input['image']=$name;
        }

        PortofolioCategory::find($id)->update($input);
        Session::flash('success','Category Updated Successfully');
        return redirect()->back();
    }

    public function destroy($id)
    {
        $category=PortofolioCategory::find($id);
        if($category->image && file_exists(public_path().'/portfolio_categories/'.$category->image)){
            unlink(public_path().'/portfolio_categories/'.$category->image);
        }
        $portofolios=Portofolio::Where('portofolio_category_id',$id)->get();

        foreach ($portofolios as $portofolio) {


            if ($portofolio->image && file_exists(public_path() . '/portfolio_categories/' . $portofolio->image)) {
                unlink(public_path() . '/portfolio_categories/' . $portofolio->image);
            }

            $portofolio->delete();
        }

        $category->delete();
        Session::flash('danger','Category Deleted Successfully');
        return redirect()->back();
    }
}
