<?php

namespace App\Http\Controllers;
use App\Service;
use App\ServiceCategory;
use App\ServiceSubCategory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use function Sodium\compare;

class AdminServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $services= Service::all();
        $categories=ServiceSubCategory::all();
        return view('admin.service.index',compact('services','categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories=ServiceCategory::all();
        $categoryFirstId=ServiceCategory::first()->id;
        $subCategories=ServiceSubCategory::where('service_category_id',$categoryFirstId)->get();
        return view('admin.service.create',compact('categories','subCategories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'image'=>'required|image|mimes:jpg,png,jpeg'
        ]);
        $input=$request->all();
        if($file=$request->file('image')){
            $name=time().$file->getClientOriginalName();
            $file->move('service',$name);
            $input['image']=$name;
        }
        Service::create($input);
        Session::flash('success','Service Added Successfully');
        return redirect('admin-service');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $services=Service::find($id);

//        $services= Service::all($id);

        return view('admin.service.show',compact('services'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $subcategories=ServiceSubCategory::all();
        $categories=ServiceCategory::all();
        $service=Service::find($id);
        return view('admin.service.edit',compact('service','subcategories','categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $input=$request->all();

        if($file=$request->file('image')){

            $path=Service::find($id)->image;
            if($path && file_exists(public_path().'/service/'.$path)){
                unlink(public_path().'/service/'.$path);
            }
            $name=time().$file->getClientOriginalName();
            $file->move('service',$name);
            $input['image']=$name;
        }

        $service=Service::find($id)->update($input);
        Session::flash('success','service Updated Successfully');
        return redirect('admin-service')->with($service);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
//        {
//            $service = Service::find($id);
//            $old_images=Service::all();
//            foreach ($old_images as $image){
//                if(file_exists(public_path().'/service/'.$image->image)){
//                    unlink(public_path().'/service/'.$image->image);
//                }
//            }
//            $service->delete();
//            Session::flash('danger','Category Deleted Successfully');
//            return redirect()->back();
//        }






        $service=  Service::find($id);
        if($service->image && file_exists(public_path().'/service/'.$service->image)){
            unlink(public_path().'/service/'.$service->image);
        }
        $service->delete();
        Session::flash('danger','service Deleted Successfully');
        return redirect()->back();
    }

    public function subCategories($id){

        $subCategories=DB::table("service_sub_categories")
            ->where("service_category_id",$id)
            ->pluck("name","id");
        return Response::json($subCategories);

    }
}
