<?php

namespace App\Http\Controllers;

use App\Service;
use App\ServiceCategory;
use App\ServiceSubCategory;
use Illuminate\Http\Request;
use App\Blog;
use App\Contact;
use App\PortofoiloImage;
use App\User;
use App\PortofolioCategory;
use App\Portofolio;
class AdminDashboardController extends Controller
{

    public function index(){

        $categories=ServiceCategory::all();
        $subcategories=ServiceSubCategory::all();
        $services=Service::all();
        $blogs= Blog::all();
        $contacts=Contact::all();
        $images = PortofoiloImage::all();
        $user=User::all();
        $categoriesPOrtofolio=PortofolioCategory::all();
        $portolios= Portofolio::all();


        return view('admin.dashboard',compact('categories','subcategories','services','blogs','contacts','images','user','categoriesPOrtofolio','portolios'));
    }
}
