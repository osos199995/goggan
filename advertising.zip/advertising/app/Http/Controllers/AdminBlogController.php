<?php

namespace App\Http\Controllers;

use App\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminBlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $blogs= Blog::all();
        return view('admin.blog.index',compact('blogs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.blog.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $request->validate([
                'image'=>'required|image|mimes:jpg,png,jpeg'
            ]);
            $input=$request->all();
            if($file=$request->file('image')){
                $name=time().$file->getClientOriginalName();
                $file->move('blogs',$name);
                $input['image']=$name;
            }

            Blog::create($input);
            Session::flash('success','blogs Added Successfully');
            return redirect('admin-blog');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $blog=Blog::find($id);
        return view('admin.blog.edit',compact('blog'));    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $input=$request->all();
        if($file=$request->file('image')){
            $path=Blog::find($id)->image;
            if($path && file_exists(public_path().'/blogs/'.$path)){
                unlink(public_path().'/blogs/'.$path);
            }
            $name=time().$file->getClientOriginalName();
            $file->move('blogs',$name);
            $input['image']=$name;
        }

        $blogs=Blog::find($id)->update($input);
        Session::flash('success','blog Updated Successfully');
        return redirect('admin-blog');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      $blog=  Blog::find($id);
        if($blog->image && file_exists(public_path().'/blogs/'.$blog->image)){
            unlink(public_path().'/blogs/'.$blog->image);
        }
        $blog->delete();
        Session::flash('danger','blog Deleted Successfully');
        return redirect()->back();

    }
}
