<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceSubCategory extends Model
{

    protected $fillable=[
      'service',
      'category_id',
      'name',
      'name_ar',
        'image',
        'service_category_id',
  'service_subcategory_id'
    ];





    public function subservice()
    {
        return $this->hasMany('App\Service', 'service_subcategory_id');
    }


    public function categories(){
        return $this->belongsTo('App\ServiceCategory','category_id');
    }
}
