<?php

namespace App;
use App\PortofolioCategory;

use Illuminate\Database\Eloquent\Model;

class Portofolio extends Model
{
    //

    protected $fillable=[


        'title',
        'title_ar',
        'description' ,
        'description_ar' ,
        'portofolio_category_id'




    ];


    public function category(){
        return $this->belongsTo('App\PortofolioCategory','portofolio_category_id');
    }

    public function images(){
        return $this->hasMany('App\PortofoiloImage','portofoilo_id');
    }



}
