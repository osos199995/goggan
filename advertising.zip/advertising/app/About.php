<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class About extends Model
{
    protected $fillable=[
        'image',
        'description',
        'description_ar',
        'facebook',
        'twitter',
        'google',
        'instgram',
        'youtube',
        'address',
        'address_ar',
        'phone1',
        'phone2',
        'email',
        'fax',
        'mission',
        'mission_ar',
        'vision',
        'vision_ar',
        'value',
        'value_ar',
    ];
}
