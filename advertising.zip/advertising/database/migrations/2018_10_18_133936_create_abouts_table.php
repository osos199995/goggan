<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAboutsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('abouts', function (Blueprint $table) {
            $table->increments('id');
            $table->string('image');
            $table->text('description');
            $table->text('description_ar');
            $table->string('facebook')->nullable();
            $table->string('twitter')->nullable();
            $table->string('google')->nullable();
            $table->string('instgram')->nullable();
            $table->string('youtube')->nullable();
            $table->string('address');
            $table->string('address_ar');
            $table->string('phone1');
            $table->string('phone2');
            $table->string('email');
            $table->string('fax');
            $table->text('mission');
            $table->text('mission_ar');
            $table->text('vision');
            $table->text('vision_ar');
            $table->text('value');
            $table->text('value_ar');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('abouts');
    }
}
