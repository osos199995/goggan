<?php

use Illuminate\Database\Seeder;

class AdminServiceSubcategoriesseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\ServiceSubCategory::create([
            'Service_category_id'=>'1',
            'name'=>'islam',
            'name_ar'=>'اسلام'


        ]);
    }
}
