<?php

use Illuminate\Database\Seeder;

class AdminServiceCategoriesseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\ServiceCategory::create([
            'name'=>'mohamed',
            'name_ar'=>'محمد',
            'image'=>'first image']);

    }
}
