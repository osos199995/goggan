<?php

use Illuminate\Database\Seeder;

class PortofoiloImageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        \App\PortofoiloImage::create([

            'portofoilo_id'=>'1',
            'image'=>'image 1'
        ]);
    }
}
