<?php

use Illuminate\Database\Seeder;

class ContactTableseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Contact::create([
            'first_name'=>'Mohamed',
            'last_name'=>'Abdelrhman',
            'subject'=>'susyhshs',
            'message'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining',
            'email'=>'email.com',
            'phone'=>'01125323518',
        ]); \App\Contact::create([
        'first_name'=>'Mohamed',
        'last_name'=>'Abdelrhman',
        'subject'=>'susyhshs',
        'message'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining',
        'email'=>'email.com',
        'phone'=>'01125323518',
    ]); \App\Contact::create([
        'first_name'=>'Mohamed',
        'last_name'=>'Abdelrhman',
        'subject'=>'susyhshs',
        'message'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining',
        'email'=>'email.com',
        'phone'=>'01125323518',
    ]);

    }
}
