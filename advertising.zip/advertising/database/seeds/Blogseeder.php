<?php

use Illuminate\Database\Seeder;

class Blogseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        \App\Blog::create([

            'image'=>'image1',
            'title'=>'title1',
            'description'=>'description1'


        ]);
    }
}
