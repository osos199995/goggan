<?php

use Illuminate\Database\Seeder;

class PortfolioCtaegoryTableseeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\PortofolioCategory::create([
            'image'=>'category1.jpg',
            'name'=>'banners',
            'name_ar'=>'banners arabic',
        ]);
        \App\PortofolioCategory::create([
            'image'=>'category2.jpg',
            'name'=>'cards',
            'name_ar'=>'cards arabic',
        ]);
        \App\PortofolioCategory::create([
            'image'=>'category3.jpg',
            'name'=>'books',
            'name_ar'=>'books arabic',
        ]);
    }
}
