<?php

use Illuminate\Database\Seeder;

class PortofolioTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        \App\Portofolio::create([
            'title'=>'title 1',
            'title_ar'=>'title 1 arabic',
            'description'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining' ,
            'description_ar'=>'ناك حقيقة مثبتة منذ زمن طويل وهي أن
             المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أ
            و شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم 
            إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا ي' ,
            'portofolio_category_id'=>'1'
        ]);
        \App\Portofolio::create([
            'title'=>'title 2',
            'title_ar'=>'title 1 arabic',
            'description'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining' ,
            'description_ar'=>'ناك حقيقة مثبتة منذ زمن طويل وهي أن
             المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أ
            و شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم 
            إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا ي' ,
            'portofolio_category_id'=>'2'
        ]);
        \App\Portofolio::create([
            'title'=>'title 3',
            'title_ar'=>'title 1 arabic',
            'description'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining' ,
            'description_ar'=>'ناك حقيقة مثبتة منذ زمن طويل وهي أن
             المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أ
            و شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم 
            إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا ي' ,
            'portofolio_category_id'=>'3'
        ]);

    }




}
