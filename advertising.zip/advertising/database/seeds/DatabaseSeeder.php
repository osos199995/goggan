<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         $this->call(UsersTableSeeder::class);
         $this->call(AboutTableSeeder::class);
         $this->call(ContactTableseeder::class);
         $this->call(PortfolioCtaegoryTableseeder::class);
        $this->call(Blogseeder::class);
         $this->call(PortofolioTableSeeder::class);
         $this->call(AdminServiceCategoriesseeder::class);
        $this->call(AdminServiceSeeder::class);
        $this->call(AdminServiceSubcategoriesseeder::class);
    }
}
