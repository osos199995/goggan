<?php

use Illuminate\Database\Seeder;

class AboutTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\About::create([
            'image'=>'about.jpg',
            'description'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining',
            'description_ar'=>'ناك حقيقة مثبتة منذ زمن طويل وهي أن
             المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أ
            و شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم 
            إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا ي',
            'facebook'=>'facebook.com',
            'twitter'=>'twitter.com',
            'google'=>'google.com',
            'instgram'=>'instgram.com',
            'youtube'=>'youtube.com',
            'address'=>'adresss thisa si',
            'address_ar'=>' الصفحة التي يقرأ',
            'phone1'=>'01125323518',
            'phone2'=>'010145841744',
            'email'=>'info@gmailk.com',
            'fax'=>'55442325',
            'mission'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining',
            'mission_ar'=>'ناك حقيقة مثبتة منذ زمن طويل وهي أن
             المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أ
            و شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم 
            إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا ي',
            'vision'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining',
            'vision_ar'=>'ناك حقيقة مثبتة منذ زمن طويل وهي أن
             المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أ
            و شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم 
            إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا ي',
            'value'=>'s simply dummy text of the printing and typesetting indust
            ry. Lorem Ipsum has been the industrys standard dummy text 
            ever since the 1500s, when an unknown printer took a galley of
             type and scrambled it to make a type specimen book. It has survived no
             t only five centuries, but also the leap into electronic typesetting, remaining',
            'value_ar'=>'ناك حقيقة مثبتة منذ زمن طويل وهي أن
             المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أ
            و شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم 
            إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام "هنا ي',
        ]);
    }
}
